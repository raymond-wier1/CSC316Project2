﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace CSC316_Lab2
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        Texture2D background_sprite;
        Texture2D target_sprite;
        Texture2D crosshair_sprite;

        SpriteFont gameFont;

        MouseState mState;
        bool mRelease = true;

        Vector2 targetPosition = new Vector2(300, 300);
        float mouseTargetDist;
        int TARGET_RADIUS = 47;

        int score;
        float timer = 30f;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = false;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            background_sprite = Content.Load<Texture2D>("forest");
            target_sprite = Content.Load<Texture2D>("duck_target_white");
            crosshair_sprite = Content.Load<Texture2D>("crosshair_blue_small");

            gameFont = Content.Load<SpriteFont>("galleryFont");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            mState = Mouse.GetState();

            mouseTargetDist = Vector2.Distance(targetPosition, new Vector2(mState.X, mState.Y));

            if(timer > 0)
            {
                timer = timer - (float)gameTime.ElapsedGameTime.TotalSeconds;

                if (mState.LeftButton == ButtonState.Pressed && mRelease == true)
                {
                    if (mouseTargetDist < TARGET_RADIUS)
                    {
                        score++;
                        Random rand = new Random();

                        targetPosition.X = rand.Next(TARGET_RADIUS, 500);
                        targetPosition.Y = rand.Next(TARGET_RADIUS, 350);
                    }
                    mRelease = false;
                }
                if (mState.LeftButton == ButtonState.Released)
                {
                    mRelease = true;
                }
            }
           

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            _spriteBatch.Begin();

            _spriteBatch.Draw(background_sprite, new Vector2(0, 0), Color.White);

            if(timer > 0)
            {
                _spriteBatch.Draw(target_sprite, new Vector2(targetPosition.X - TARGET_RADIUS, targetPosition.Y - TARGET_RADIUS), Color.White);

                _spriteBatch.DrawString(gameFont, "Good Morning!", new Vector2(10, 10), Color.Red);
                _spriteBatch.DrawString(gameFont, score.ToString(), new Vector2(10, 40), Color.Red);
                _spriteBatch.DrawString(gameFont, Math.Ceiling(timer).ToString(), new Vector2(10, 70), Color.Red);
            }
            else
            {
                _spriteBatch.DrawString(gameFont, "Final Score", new Vector2(250, 200), Color.Red);
                _spriteBatch.DrawString(gameFont, score.ToString(), new Vector2(250, 230), Color.Red);
            }
            _spriteBatch.Draw(crosshair_sprite, new Vector2(Mouse.GetState().X, Mouse.GetState().Y), Color.White);

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
